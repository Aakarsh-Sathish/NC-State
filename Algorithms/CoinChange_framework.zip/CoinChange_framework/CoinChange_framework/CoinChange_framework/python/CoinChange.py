#DO NOT CHANGE ANY EXISTING CODE IN THIS FILE
class CoinChange:

	def NumberofCoins(self,denomination,value):
		 #Write your code here to find out minimum number of coins required to provide the change for given value.
		 #This method will have a denomination array and an int which specifies the value as inputs(Please see testcase file)
		 #This method should return the number of coins
		n = len(denomination)
		dp = [[float('inf')] * (value + 1) for _ in range(n+1)]
		for i in range(n+1):
			dp[i][0] = 0
		for i in range(1,n+1):
		 	for j in range(1,value + 1):
				 if denomination[i-1] <=j:
					 include_current_coin = dp[i][j-denomination[i-1]] + 1
					 exclude_current_coin = dp[i-1][j]
					 dp[i][j] = min(include_current_coin,exclude_current_coin)
				 else:
					 dp[i][j] = dp[i-1][j]
		return dp[n][value] if dp[n][value] != float('inf') else 0

 		

		
		 


