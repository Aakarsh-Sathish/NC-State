javac -cp .:junit-4.12.jar CoinChange.java CoinChangeTest.java
