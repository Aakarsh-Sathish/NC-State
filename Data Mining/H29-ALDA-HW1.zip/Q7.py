# Import Necessary Libraries
import numpy as np
import pandas as pd
from scipy.spatial.distance import cosine
from sklearn.metrics.pairwise import cosine_similarity
import matplotlib.pyplot as plt

print("\nQuestion 7 Answers:")

# Read the data file into a pandas dataframe
dataset = pd.read_csv('SeoulBikeData.csv', encoding='unicode_escape')

print('\nQuestion 7 (a):\n')

print('Few rows of the dataset:\n', dataset.head())

# Check for missing values in the dataset
print('\nCheck for missing values:\n', dataset.isna().sum())

# Check for duplicated rows in the dataset
print('\nCheck for duplicate values:\n', dataset.duplicated().sum())

# Create a scatter plot of Visibility vs. Humidity
plt.figure(figsize=(10, 10))
plt.scatter(dataset['Visibility (10m)'], dataset['Humidity(%)'], c ="blue")
plt.title("Visibility and Humidity")
plt.xlabel("Visibility (10m)")
plt.ylabel("Humidity(%)")
plt.show()

# Calculate the mean visibility and mean humidity
mean_visibility = np.mean(dataset['Visibility (10m)'])
print('\nMean of Visibility: ', mean_visibility)

mean_humidity = np.mean(dataset['Humidity(%)'])
print('\nMean of Humidity: ', mean_humidity)

print('\nQuestion 7 (b):')

# Create a point P using the mean values
P = (mean_visibility,mean_humidity)
print('\nPoint P:',P)

print('\nQuestion 7 (c):')

# Create a list of (x, y) pairs for visibility and humidity
vis_hum_dp = [(x, y) for x, y in zip(dataset['Visibility (10m)'],dataset['Humidity(%)'])]

# Calculate distances using different distance metrics (Euclidean, Manhattan, Minkowski, Chebyshev, Cosine)
distances_euclidean = [[np.sqrt((x - P[0])**2 + (y - P[1])**2),[x,y]] for x, y in vis_hum_dp]
distances_manhattan = [[abs(x - P[0]) + abs(y - P[1]),[x,y]] for x, y in vis_hum_dp]
distances_minkowski = [[np.power(np.power(abs(x - P[0]), 7) + np.power(abs(y - P[1]), 7), 1/7),[x,y]] for x, y in vis_hum_dp] 
distances_chebyshev = [[max(abs(x - P[0]), abs(y - P[1])),[x,y]] for x, y in vis_hum_dp]
distances_cosine = [[(1.0 - (np.dot(P, i) / (np.linalg.norm(P) * np.linalg.norm(i)))),list(i)] for i in vis_hum_dp ] 

# Find the 6 closest points using each distance metric
closest_points_euclidean = sorted(distances_euclidean,key=(lambda x:x[0]))[:6]
closest_points_manhattan = sorted(distances_manhattan,key=(lambda x:x[0]))[:6]
closest_points_minkowski = sorted(distances_minkowski,key=(lambda x:x[0]))[:6]
closest_points_chebyshev = sorted(distances_chebyshev,key=(lambda x:x[0]))[:6]
closest_points_cosine = sorted(distances_cosine,key=(lambda x:x[0]))[:6] 

# Print the 6 closest distances for each metric
print("6 closest euclidean distances:\n",closest_points_euclidean,
      "\n6 closest manhattan distances:\n",closest_points_manhattan,
      "\n6 closest minkowski distances:\n",closest_points_minkowski,
      "\n6 closest chebyshev distances:\n",closest_points_chebyshev, 
      "\n6 closest cosine distances:\n",closest_points_cosine)

print('\nQuestion 7 (d):')

# Find the 20 closest points using each distance metric
twenty_closest_points_euclidean = sorted(distances_euclidean,key=(lambda x:x[0]))[:20]
twenty_closest_points_manhattan = sorted(distances_manhattan,key=(lambda x:x[0]))[:20]
twenty_closest_points_minkowski = sorted(distances_minkowski,key=(lambda x:x[0]))[:20]
twenty_closest_points_chebyshev = sorted(distances_chebyshev,key=(lambda x:x[0]))[:20]
twenty_closest_points_cosine = sorted(distances_cosine,key=(lambda x:x[0]))[:20]

# Extract x and y coordinates for the 20 closest points
P_x, P_y = P
euclidean_dist_x, euclidean_dist_y = zip(*[i[1] for i in twenty_closest_points_euclidean])
manhattan_dist_x, manhattan_dist_y = zip(*[i[1] for i in twenty_closest_points_manhattan])
minkowski_dist_x, minkowski_dist_y = zip(*[i[1] for i in twenty_closest_points_minkowski])
chebyshev_dist_x, chebyshev_dist_y = zip(*[i[1] for i in twenty_closest_points_chebyshev])
cosine_dist_x, cosine_dist_y = zip(*[i[1] for i in twenty_closest_points_cosine])

# Create scatter plots for the 20 closest points using each distance metric
plt.figure(figsize=(10, 10))
other_points = plt.scatter(dataset['Visibility (10m)'], dataset['Humidity(%)'], c ="lightsteelblue", label='Other Points')
nearest_points = plt.scatter(euclidean_dist_x, euclidean_dist_y, label='Closest Points', c='red')
point = plt.scatter(P_x, P_y, marker = 'o', c='blue', label='Point P')
plt.legend(handles=[point, nearest_points, other_points])
plt.xlabel('X-axis')
plt.ylabel('Y-axis')
plt.title('Scatter Plot for nearest euclidean distances')
plt.show()

plt.figure(figsize=(10, 10))
other_points = plt.scatter(dataset['Visibility (10m)'], dataset['Humidity(%)'], c ="lightsteelblue", label='Other Points')
nearest_points = plt.scatter(manhattan_dist_x, manhattan_dist_y, label='Closest Points', c='red')
point = plt.scatter(P_x, P_y, marker = 'o', c='blue', label='Point P')
plt.legend(handles=[point, nearest_points, other_points])
plt.xlabel('X-axis')
plt.ylabel('Y-axis')
plt.title('Scatter Plot for nearest manhattan distances')
plt.show()

plt.figure(figsize=(10, 10))
other_points = plt.scatter(dataset['Visibility (10m)'], dataset['Humidity(%)'], c ="lightsteelblue", label='Other Points')
nearest_points = plt.scatter(minkowski_dist_x, minkowski_dist_y, label='Closest Points', c='red')
point = plt.scatter(P_x, P_y, marker = 'o', c='blue', label='Point P')
plt.legend(handles=[point, nearest_points, other_points])
plt.xlabel('X-axis')
plt.ylabel('Y-axis')
plt.title('Scatter Plot for nearest minkowski distances')
plt.show()

plt.figure(figsize=(10, 10))
other_points = plt.scatter(dataset['Visibility (10m)'], dataset['Humidity(%)'], c ="lightsteelblue", label='Other Points')
nearest_points = plt.scatter(chebyshev_dist_x, chebyshev_dist_y, label='Closest Points', c='red')
point = plt.scatter(P_x, P_y, marker = 'o', c='blue', label='Point P')
plt.legend(handles=[point, nearest_points, other_points])
plt.xlabel('X-axis')
plt.ylabel('Y-axis')
plt.title('Scatter Plot for nearest chebyshev distances')
plt.show()

plt.figure(figsize=(10, 10))
other_points = plt.scatter(dataset['Visibility (10m)'], dataset['Humidity(%)'], c ="lightsteelblue", label='Other Points')
nearest_points = plt.scatter(cosine_dist_x, cosine_dist_y, label='Closest Points', c='red')
point = plt.scatter(P_x, P_y, marker = 'o', c='blue', label='Point P')
plt.legend(handles=[point, nearest_points, other_points])
plt.xlabel('X-axis')
plt.ylabel('Y-axis')
plt.title('Scatter Plot for nearest cosine distances')
plt.show()