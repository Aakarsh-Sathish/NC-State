# Import Necessary Libraries
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import statsmodels.api as sm
import numpy as np
import scipy.stats as stats

print("\nQuestion 3 Answers:")

# Read the data file into a pandas dataframe
dataset = pd.read_csv('abalone.data', header=None,
          names=['Sex', 'Length', 'Diameter', 'Height', 'Whole Weight',
          'Shucked Weight', 'Viscera Weight', 'Shell Weight', 'Rings'])

print('\nQuestion 3 (a):')

# Compute mean, median, standard deviation, range, 25th percentile, 50th percentile, 75th percentile
for attr in ['Length', 'Diameter', 'Height', 'Whole Weight']:
    print(f"{attr}'s Mean: {np.mean(dataset[attr])}")
    print(f"{attr}'s Median: {np.median(dataset[attr])}")
    print(f"{attr}'s Standard DeviatDion: {np.std(dataset[attr])}")
    print(f"{attr}'s Range: {np.ptp(dataset[attr])}")
    print(f"{attr}'s 25th Percentile: {np.percentile(dataset[attr],25)}")
    print(f"{attr}'s 50th Percentile: {np.percentile(dataset[attr],50)}")
    print(f"{attr}'s 75th Percentile: {np.percentile(dataset[attr],75)}\n")

print('\nQuestion 3 (b):')

# Box-and-whisker plots for Length and Whole Weight grouped by Sex
plt.figure(figsize=(12, 5))
plt.subplot(1, 2, 1)
# Box-and-whisker plot for Length
sns.boxplot(x='Sex', y='Length', data=dataset)
plt.title('Box Plot of Length grouped by Sex')
plt.subplot(1, 2, 2)
# Box-and-whisker plot for Whole Weight
sns.boxplot(x='Sex', y='Whole Weight', data=dataset)
plt.title('Box Plot of Whole Weight grouped by Sex')
plt.tight_layout()
plt.show()

print('\nQuestion 3 (c):')

# Create histogram plots for Shell Weight and Rings
plt.figure(figsize=(12, 5))
plt.subplot(1, 2, 1)
# Create histogram plot for Shell Weight
plt.hist(dataset['Shell Weight'], bins=16, color='red')
plt.title('Shell Weight Histogram')
plt.xlabel('Shell Weight')
plt.ylabel('Frequency')
plt.subplot(1, 2, 2)
# Create histogram plot for Rings
plt.hist(dataset['Rings'], bins=16, color='blue')
plt.title('Rings Histogram')
plt.xlabel('Rings')
plt.ylabel('Frequency')
plt.tight_layout()
plt.show()

print('\nQuestion 3 (d):')

sns.set(style="ticks")
KDE_scatter_matrix = sns.pairplot(
    dataset[['Diameter', 'Height', 'Shell Weight', 'Rings', 'Sex']],
    hue="Sex",
    palette={'M': 'blue', 'F': 'red', 'I': 'green'},
    diag_kind="kde",
    markers=["o", "s", "D"],
    height=2.5
)

plt.subplots_adjust(top=0.95)
plt.suptitle('Scatter Matrix with KDE')
plt.show()

print('\nQuestion 3 (e):')

# 3D scatter plot with Diameter, Shell Weight, and Rings, colored by Sex
fig = plt.figure(figsize=(20, 8))
ax = fig.add_subplot(111, projection='3d')
ax.set_box_aspect(aspect=None, zoom=0.9)
sexes = {"M": "red", "F": "green", "I": "blue"}
for sex in dataset['Sex'].unique():
    subset = dataset[dataset['Sex'] == sex]
    ax.scatter(subset['Diameter'], subset['Shell Weight'], subset['Rings'], c=sexes[sex], label=sex)
ax.set_xlabel('Diameter')
ax.set_ylabel('Shell Weight')
ax.set_zlabel('Rings')
plt.title('3D Scatter Plot')
plt.legend()
plt.tight_layout()
plt.show()

print('\nQuestion 3 (f):')

# Create Q-Q plot for "length"
plt.figure(figsize=(8, 4))
stats.probplot(dataset['Length'], dist="norm", plot=plt)
plt.title("Q-Q Plot for Length")
plt.xlabel("Theoretical Quantiles")
plt.ylabel("Sample Quantiles")
plt.show()

# Create Q-Q plot for "whole weight"
plt.figure(figsize=(8, 4))
stats.probplot(dataset['Whole Weight'], dist="norm", plot=plt)
plt.title("Q-Q Plot for Whole Weight")
plt.xlabel("Theoretical Quantiles")
plt.ylabel("Sample Quantiles")
plt.show()