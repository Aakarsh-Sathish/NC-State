# Import Necessary Libraries
import numpy as np

print("\nQuestion 2 Answers:")
# Question 2 (a)
A = np.ones((5,5))
print('\nQuestion 2 (a):')
print(A)

# Question 2 (b)
A[2] = 3
print('\nQuestion 2 (b):')
print(A)

# Question 2 (c)
s = np.sum(A, axis=1)
print('\nQuestion 2 (c):')
print(s)

# Question 2 (d)
A = np.column_stack((A, s))
print('\nQuestion 2 (d):')
print(A)

# Question 2 (e)
A = np.transpose(A)
print('\nQuestion 2 (e):')
print(A)

# Question 2 (f)
np.random.seed(2023)
B1 = np.std(A, axis=1)
B2 = np.random.uniform(0,1,6)
B = np.row_stack((B1,B2))
print('\nQuestion 2 (f):')
print(B)

# Question 2 (g)
C = np.matmul(B,A)
print('\nQuestion 2 (g):')
print('C:\n', C)

# Question 2 (h)
print('\nQuestion 2 (h):')
X = np.transpose([1,2,3,4])
print('\nX:', X)

Y = np.transpose([1,2,4,8])
print('Y:',Y)

Z = np.transpose([7,3,5,1])
print('Z:',Z)

mat = np.row_stack((X, Y, Z))
print('\nMatrix:\n', mat)

cov = np.cov(mat)
print('\nCovariance Matrix:\n',cov)

Pearson_coef = np.corrcoef(X, Y)
print('\nPearson_coef:\n', Pearson_coef)

# Question 2 (i)
print('\nQuestion 2 (i):')
x = np.array([7, 12, 10, 9, 14, 10, 11]).T
print('\nx =',x)

x_population_mean = np.mean(x)
print("\nMean of population x =", x_population_mean)
x_sample_mean = np.sum(x)/(len(x)-1)
print("\nMean of sample x =", x_sample_mean)
x_population_std = np.std(x)
print("\nStandard deviation of population =", x_population_std)
x_sample_std = np.std(x, ddof=1)
print("\nStandard deviation of sample =", x_sample_std)

lhs = np.square(x)
lhs_population_mean = np.mean(lhs)
print("\ni) LHS = Mean of x^2 =", lhs_population_mean)
rhs_population = x_population_mean**2 + x_population_std**2
print("     RHS = ", rhs_population)
print('The given equation is ' + str(lhs_population_mean==rhs_population) + ' for population')

lhs_sample_mean = np.sum(lhs)/(len(lhs)-1)
print("\nii) LHS = Mean of x^2 =", lhs_sample_mean)
rhs_sample = x_sample_mean**2 + x_sample_std**2
print("    RHS = ", rhs_sample)
print('The given equation is ' + str(lhs_sample_mean==rhs_sample) + ' for sample')